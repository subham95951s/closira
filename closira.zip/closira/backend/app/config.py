from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    DATABASE_URL: str = "postgresql://closira:closira_pass@localhost:5432/closira_db"
    REDIS_URL: str = "redis://localhost:6379/0"
    APP_ENV: str = "development"
    LOG_LEVEL: str = "INFO"


settings = Settings()
