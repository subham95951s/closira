from dataclasses import dataclass


@dataclass
class SOPResult:
    matched: bool
    sop_name: str | None
    suggested_response: str | None


# ── SOP Definitions ───────────────────────────────────────────────────────────
# Each SOP has a name, keywords (any match triggers it), and a response template.
# Keywords are checked case-insensitively against the full message text.

_SOPS = [
    {
        "name": "booking_enquiry",
        "keywords": ["book", "appointment", "schedule", "slot", "reserve", "availability", "available"],
        "response": (
            "Thank you for reaching out! We'd love to help you book an appointment. "
            "We currently have slots available — please let us know your preferred date "
            "and time and we'll confirm within the hour."
        ),
    },
    {
        "name": "pricing_question",
        "keywords": ["price", "cost", "fee", "rate", "charge", "quote", "how much", "pricing", "charges"],
        "response": (
            "Great question! Our pricing depends on the service you need. "
            "Our packages start from ₹999. Could you share more details about "
            "what you're looking for so we can send you an accurate quote?"
        ),
    },
    {
        "name": "complaint",
        "keywords": ["complaint", "unhappy", "disappointed", "problem", "issue", "bad", "worst",
                     "terrible", "awful", "not working", "broken", "refund", "angry", "frustrated"],
        "response": (
            "We're truly sorry to hear about your experience. This is not the standard "
            "we hold ourselves to. A member of our team will personally reach out to you "
            "within 30 minutes to make this right."
        ),
    },
    {
        "name": "after_hours",
        "keywords": ["after hours", "closed", "tonight", "weekend", "tomorrow morning",
                     "late night", "sunday", "saturday", "holiday", "office hours"],
        "response": (
            "Thanks for your message! Our office is currently closed, but we've received "
            "your enquiry and will respond first thing when we're back. "
            "For urgent matters, please call our helpline."
        ),
    },
    {
        "name": "general_info",
        "keywords": ["info", "information", "details", "tell me", "what is", "how does",
                     "explain", "about", "services", "offerings", "what do you"],
        "response": (
            "Thanks for your interest! We'd be happy to share more details about our services. "
            "Could you let us know what specifically you'd like to know more about? "
            "We'll send you all the relevant information right away."
        ),
    },
]


class SOPMatcher:
    """
    Keyword-based SOP matcher.
    Iterates SOPs in order; returns the first match.
    Case-insensitive substring match against the full message.
    """

    def match(self, message: str) -> SOPResult:
        lowered = message.lower()
        for sop in _SOPS:
            for keyword in sop["keywords"]:
                if keyword in lowered:
                    return SOPResult(
                        matched=True,
                        sop_name=sop["name"],
                        suggested_response=sop["response"],
                    )
        return SOPResult(matched=False, sop_name=None, suggested_response=None)


# Singleton instance shared across the app
sop_matcher = SOPMatcher()
