from fastapi import APIRouter
from app.database import check_db_connection
from app.schemas.enquiry import HealthOut
from app.config import settings

router = APIRouter(tags=["Health"])


@router.get(
    "/health",
    response_model=HealthOut,
    summary="API health check",
    description="Returns API status, database connectivity, and Celery worker status.",
)
def health_check():
    db_ok = check_db_connection()

    # Ping Celery via Redis inspect (non-blocking, 1s timeout)
    try:
        from app.worker.celery_app import celery_app
        inspector = celery_app.control.inspect(timeout=1.0)
        active = inspector.active()
        worker_status = "online" if active else "no_workers"
    except Exception:
        worker_status = "unreachable"

    return HealthOut(
        status="ok" if db_ok else "degraded",
        db_connected=db_ok,
        worker_status=worker_status,
        app_env=settings.APP_ENV,
    )
