from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.enquiry import Enquiry
from app.models.event import StatusEvent
from app.schemas.enquiry import (
    EnquiryCreate, EnquiryCreatedOut, EnquiryHistoryOut,
    FollowUpRequest, EscalateRequest, EnquiryOut, StatusEventOut,
)
from app.logging_config import logger

router = APIRouter(prefix="/enquiry", tags=["Enquiry"])


def _get_enquiry_or_404(enquiry_id: str, db: Session) -> Enquiry:
    enquiry = db.get(Enquiry, enquiry_id)
    if not enquiry:
        raise HTTPException(status_code=404, detail=f"Enquiry '{enquiry_id}' not found")
    return enquiry


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=EnquiryCreatedOut,
    summary="Create a new inbound customer enquiry",
    description=(
        "Accepts an inbound customer message. Persists the enquiry immediately and "
        "dispatches an async Celery task for SOP matching. Returns the job_id instantly."
    ),
)
def create_enquiry(payload: EnquiryCreate, db: Session = Depends(get_db)):
    from app.worker.tasks import process_enquiry  # lazy import avoids circular

    enquiry = Enquiry(
        channel=payload.channel,
        customer_name=payload.customer_name,
        message=payload.message,
        status="new",
    )
    db.add(enquiry)
    db.flush()  # get the id before commit

    db.add(StatusEvent(
        enquiry_id=enquiry.id,
        event_type="created",
        description=f"Enquiry received via {payload.channel}",
        actor="system",
    ))
    db.commit()
    db.refresh(enquiry)

    # Dispatch async task — non-blocking
    process_enquiry.delay(enquiry.id)

    logger.info(
        "enquiry_created",
        enquiry_id=enquiry.id,
        channel=payload.channel,
        customer=payload.customer_name,
    )
    return EnquiryCreatedOut(job_id=enquiry.id, status=enquiry.status)


@router.post(
    "/{enquiry_id}/followup",
    response_model=EnquiryOut,
    summary="Schedule a follow-up for an open enquiry",
    description="Sets a follow-up timestamp (now + delay_minutes) and optional message template.",
)
def schedule_followup(
    enquiry_id: str,
    payload: FollowUpRequest,
    db: Session = Depends(get_db),
):
    enquiry = _get_enquiry_or_404(enquiry_id, db)

    if enquiry.status == "escalated":
        raise HTTPException(400, "Cannot schedule follow-up on an escalated enquiry")
    if enquiry.status == "closed":
        raise HTTPException(400, "Cannot schedule follow-up on a closed enquiry")

    due_at = datetime.now(timezone.utc) + timedelta(minutes=payload.delay_minutes)
    enquiry.followup_due_at = due_at
    enquiry.followup_template = payload.message_template

    db.add(StatusEvent(
        enquiry_id=enquiry_id,
        event_type="followup_scheduled",
        description=f"Follow-up due in {payload.delay_minutes} min at {due_at.isoformat()}",
        actor="agent",
    ))
    db.commit()
    db.refresh(enquiry)

    logger.info("followup_scheduled", enquiry_id=enquiry_id, due_at=due_at.isoformat())
    return EnquiryOut.model_validate(enquiry)


@router.post(
    "/{enquiry_id}/escalate",
    response_model=EnquiryOut,
    summary="Escalate an enquiry to a human agent",
    description="Marks the enquiry as escalated. Idempotent if already escalated.",
)
def escalate_enquiry(
    enquiry_id: str,
    payload: EscalateRequest,
    db: Session = Depends(get_db),
):
    enquiry = _get_enquiry_or_404(enquiry_id, db)

    if enquiry.status == "closed":
        raise HTTPException(400, "Cannot escalate a closed enquiry")

    prev_status = enquiry.status
    enquiry.status = "escalated"
    enquiry.escalation_reason = payload.reason

    db.add(StatusEvent(
        enquiry_id=enquiry_id,
        event_type="escalated",
        description=f"Escalated by agent. Reason: {payload.reason}",
        actor="agent",
    ))
    db.commit()
    db.refresh(enquiry)

    logger.info(
        "enquiry_escalated",
        enquiry_id=enquiry_id,
        reason=payload.reason,
        previous_status=prev_status,
    )
    return EnquiryOut.model_validate(enquiry)


@router.get(
    "/{enquiry_id}/history",
    response_model=EnquiryHistoryOut,
    summary="Get full conversation history and status timeline",
    description="Returns the enquiry record plus all status events in chronological order.",
)
def get_history(enquiry_id: str, db: Session = Depends(get_db)):
    enquiry = _get_enquiry_or_404(enquiry_id, db)
    return EnquiryHistoryOut(
        enquiry=EnquiryOut.model_validate(enquiry),
        events=[StatusEventOut.model_validate(e) for e in enquiry.events],
    )
