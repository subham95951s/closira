from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from app.logging_config import configure_logging, logger
from app.database import engine
from app.models import Enquiry, StatusEvent  # noqa: F401 — ensure models are registered
from app.database import Base
from app.routers import enquiry as enquiry_router
from app.routers import health as health_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    # Create tables on startup (Alembic handles prod migrations; this covers dev)
    Base.metadata.create_all(bind=engine)
    logger.info("app_startup", message="Closira API started")
    yield
    logger.info("app_shutdown", message="Closira API shutting down")


app = FastAPI(
    title="Closira Enquiry API",
    description=(
        "REST API powering Closira's customer enquiry-handling pipeline. "
        "Handles inbound enquiries, async SOP matching, follow-ups, and escalations."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(enquiry_router.router)
app.include_router(health_router.router)


# ── Global Exception Handler ──────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(
        "unhandled_exception",
        path=str(request.url),
        method=request.method,
        error=str(exc),
        exc_info=True,
    )
    return JSONResponse(
        status_code=500,
        content={"detail": "An internal error occurred. Please try again later."},
    )


@app.get("/", include_in_schema=False)
def root():
    return {"message": "Closira API — visit /docs for the full API reference"}
