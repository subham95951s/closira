from celery import Task
from app.worker.celery_app import celery_app
from app.database import SessionLocal
from app.models.enquiry import Enquiry
from app.models.event import StatusEvent
from app.services.sop_matcher import sop_matcher
from app.logging_config import logger


class DatabaseTask(Task):
    """Base task that provides a DB session and handles cleanup."""
    abstract = True

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logger.error("task_failed", task_id=task_id, error=str(exc))


@celery_app.task(
    bind=True,
    base=DatabaseTask,
    name="process_enquiry",
    max_retries=3,
    default_retry_delay=5,
)
def process_enquiry(self, enquiry_id: str) -> dict:
    """
    Background task: match inbound enquiry to a SOP, update DB, log events.
    Retries up to 3 times on transient failures.
    """
    db = SessionLocal()
    try:
        # ── Step 1: Load enquiry ─────────────────────────────────────────────
        enquiry = db.get(Enquiry, enquiry_id)
        if not enquiry:
            logger.warning("task_enquiry_not_found", enquiry_id=enquiry_id)
            return {"status": "not_found", "enquiry_id": enquiry_id}

        logger.info("task_started", enquiry_id=enquiry_id, channel=enquiry.channel)

        # Set status to processing
        enquiry.status = "processing"
        db.add(StatusEvent(
            enquiry_id=enquiry_id,
            event_type="processing_started",
            description="Background task picked up the enquiry",
            actor="system",
        ))
        db.commit()

        # ── Step 2: SOP matching ─────────────────────────────────────────────
        result = sop_matcher.match(enquiry.message)

        if result.matched:
            # ── Step 3a: SOP matched ─────────────────────────────────────────
            enquiry.status = "open"
            enquiry.matched_sop = result.sop_name
            enquiry.suggested_response = result.suggested_response
            db.add(StatusEvent(
                enquiry_id=enquiry_id,
                event_type="sop_matched",
                description=f"Matched SOP: {result.sop_name}",
                actor="system",
            ))
            logger.info(
                "sop_matched",
                enquiry_id=enquiry_id,
                sop=result.sop_name,
                customer=enquiry.customer_name,
            )
        else:
            # ── Step 3b: No match → auto-escalate ────────────────────────────
            enquiry.status = "escalated"
            enquiry.escalation_reason = "No SOP matched — requires human review"
            db.add(StatusEvent(
                enquiry_id=enquiry_id,
                event_type="escalation_triggered",
                description="No SOP matched; enquiry auto-escalated",
                actor="system",
            ))
            logger.warning(
                "escalation_triggered",
                enquiry_id=enquiry_id,
                reason="no_sop_match",
                message_preview=enquiry.message[:80],
            )

        # ── Step 4: Commit ───────────────────────────────────────────────────
        db.commit()
        logger.info("task_completed", enquiry_id=enquiry_id, final_status=enquiry.status)
        return {"status": enquiry.status, "enquiry_id": enquiry_id, "matched_sop": enquiry.matched_sop}

    except Exception as exc:
        db.rollback()
        logger.error("task_error", enquiry_id=enquiry_id, error=str(exc), exc_info=True)
        raise self.retry(exc=exc)
    finally:
        db.close()
