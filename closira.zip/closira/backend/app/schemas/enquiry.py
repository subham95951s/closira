from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel, Field


# ── Enums ──────────────────────────────────────────────────────────────────────
Channel = Literal["whatsapp", "email", "call"]
Status  = Literal["new", "processing", "open", "escalated", "closed"]
Actor   = Literal["system", "agent"]


# ── Status Events ─────────────────────────────────────────────────────────────
class StatusEventOut(BaseModel):
    id: str
    event_type: str
    description: Optional[str]
    actor: Actor
    created_at: datetime

    model_config = {"from_attributes": True}


# ── Enquiry Create ─────────────────────────────────────────────────────────────
class EnquiryCreate(BaseModel):
    channel: Channel = Field(..., examples=["whatsapp"], description="Inbound channel")
    customer_name: str = Field(..., min_length=1, max_length=100, examples=["Sarah M."])
    message: str = Field(..., min_length=1, examples=["Hi, I'd like to book an appointment."])


# ── Enquiry Response ───────────────────────────────────────────────────────────
class EnquiryOut(BaseModel):
    id: str
    channel: Channel
    customer_name: str
    message: str
    status: Status
    matched_sop: Optional[str]
    suggested_response: Optional[str]
    escalation_reason: Optional[str]
    followup_due_at: Optional[datetime]
    followup_template: Optional[str]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class EnquiryCreatedOut(BaseModel):
    job_id: str = Field(..., description="Enquiry UUID — use as job_id to poll status")
    status: Status


# ── Enquiry History ────────────────────────────────────────────────────────────
class EnquiryHistoryOut(BaseModel):
    enquiry: EnquiryOut
    events: list[StatusEventOut]


# ── Follow-up Request ─────────────────────────────────────────────────────────
class FollowUpRequest(BaseModel):
    delay_minutes: int = Field(..., gt=0, le=10080, examples=[60], description="Minutes from now")
    message_template: Optional[str] = Field(None, examples=["Hi {name}, just following up!"])


# ── Escalate Request ─────────────────────────────────────────────────────────
class EscalateRequest(BaseModel):
    reason: str = Field(..., min_length=1, max_length=500, examples=["Customer requested manager callback"])


# ── Health ─────────────────────────────────────────────────────────────────────
class HealthOut(BaseModel):
    status: Literal["ok", "degraded"]
    db_connected: bool
    worker_status: str
    app_env: str
