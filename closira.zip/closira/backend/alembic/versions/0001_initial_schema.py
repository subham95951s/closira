"""initial schema

Revision ID: 0001
Revises: 
Create Date: 2025-05-23

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "enquiries",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("channel", sa.String(20), nullable=False),
        sa.Column("customer_name", sa.String(100), nullable=False),
        sa.Column("message", sa.Text, nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="new"),
        sa.Column("matched_sop", sa.String(50), nullable=True),
        sa.Column("suggested_response", sa.Text, nullable=True),
        sa.Column("escalation_reason", sa.Text, nullable=True),
        sa.Column("followup_due_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("followup_template", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
    )
    op.create_table(
        "status_events",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("enquiry_id", sa.String(36), sa.ForeignKey("enquiries.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("event_type", sa.String(30), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("actor", sa.String(20), nullable=False, server_default="system"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("status_events")
    op.drop_table("enquiries")
