"""
Integration tests for the enquiry API endpoints.
Uses an in-memory SQLite database — no Docker required.
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from unittest.mock import patch

from app.main import app
from app.database import Base, get_db

# ── In-memory SQLite test DB ──────────────────────────────────────────────────
TEST_DB_URL = "sqlite:///./test.db"
test_engine = create_engine(TEST_DB_URL, connect_args={"check_same_thread": False})
TestSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)


def override_get_db():
    db = TestSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=test_engine)
    yield
    Base.metadata.drop_all(bind=test_engine)


@pytest.fixture
def client():
    app.dependency_overrides[get_db] = override_get_db
    with patch("app.worker.tasks.process_enquiry.delay"):  # mock Celery
        yield TestClient(app)
    app.dependency_overrides.clear()


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_create_enquiry_returns_201(client):
    resp = client.post("/enquiry", json={
        "channel": "whatsapp",
        "customer_name": "Alice",
        "message": "I'd like to book an appointment",
    })
    assert resp.status_code == 201
    data = resp.json()
    assert "job_id" in data
    assert data["status"] == "new"


def test_create_enquiry_invalid_channel(client):
    resp = client.post("/enquiry", json={
        "channel": "telegram",
        "customer_name": "Bob",
        "message": "Hello",
    })
    assert resp.status_code == 422


def test_create_enquiry_missing_fields(client):
    resp = client.post("/enquiry", json={"channel": "email"})
    assert resp.status_code == 422


def test_schedule_followup(client):
    create_resp = client.post("/enquiry", json={
        "channel": "email",
        "customer_name": "Carol",
        "message": "I need information about pricing",
    })
    enquiry_id = create_resp.json()["job_id"]

    resp = client.post(f"/enquiry/{enquiry_id}/followup", json={
        "delay_minutes": 30,
        "message_template": "Hi {name}, just following up!",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["followup_due_at"] is not None
    assert data["followup_template"] == "Hi {name}, just following up!"


def test_escalate_enquiry(client):
    create_resp = client.post("/enquiry", json={
        "channel": "call",
        "customer_name": "Dave",
        "message": "Something went very wrong",
    })
    enquiry_id = create_resp.json()["job_id"]

    resp = client.post(f"/enquiry/{enquiry_id}/escalate", json={
        "reason": "Customer requested manager callback",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "escalated"
    assert data["escalation_reason"] == "Customer requested manager callback"


def test_get_history(client):
    create_resp = client.post("/enquiry", json={
        "channel": "whatsapp",
        "customer_name": "Eve",
        "message": "Can you tell me about your services?",
    })
    enquiry_id = create_resp.json()["job_id"]

    resp = client.get(f"/enquiry/{enquiry_id}/history")
    assert resp.status_code == 200
    data = resp.json()
    assert "enquiry" in data
    assert "events" in data
    assert len(data["events"]) >= 1
    assert data["events"][0]["event_type"] == "created"


def test_get_history_not_found(client):
    resp = client.get("/enquiry/nonexistent-id/history")
    assert resp.status_code == 404


def test_escalate_closed_enquiry_rejected(client):
    """Closed enquiries cannot be escalated."""
    create_resp = client.post("/enquiry", json={
        "channel": "email",
        "customer_name": "Frank",
        "message": "Test",
    })
    enquiry_id = create_resp.json()["job_id"]

    # Manually force closed via DB
    db = TestSessionLocal()
    from app.models.enquiry import Enquiry
    e = db.get(Enquiry, enquiry_id)
    e.status = "closed"
    db.commit()
    db.close()

    resp = client.post(f"/enquiry/{enquiry_id}/escalate", json={"reason": "test"})
    assert resp.status_code == 400


def test_health_endpoint(client):
    with patch("app.routers.health.check_db_connection", return_value=True):
        resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert "status" in data
    assert "db_connected" in data
