import pytest
from app.services.sop_matcher import SOPMatcher


@pytest.fixture
def matcher():
    return SOPMatcher()


def test_booking_enquiry(matcher):
    result = matcher.match("Hi, I'd like to book an appointment for tomorrow")
    assert result.matched is True
    assert result.sop_name == "booking_enquiry"
    assert result.suggested_response is not None


def test_pricing_question(matcher):
    result = matcher.match("What is the cost of your premium package?")
    assert result.matched is True
    assert result.sop_name == "pricing_question"


def test_complaint(matcher):
    result = matcher.match("I am really unhappy with the service I received")
    assert result.matched is True
    assert result.sop_name == "complaint"


def test_after_hours(matcher):
    result = matcher.match("Are you open on the weekend?")
    assert result.matched is True
    assert result.sop_name == "after_hours"


def test_general_info(matcher):
    result = matcher.match("Can you tell me more about your services?")
    assert result.matched is True
    assert result.sop_name == "general_info"


def test_no_match_returns_false(matcher):
    result = matcher.match("xyzzy qwerty nonsense blah")
    assert result.matched is False
    assert result.sop_name is None
    assert result.suggested_response is None


def test_case_insensitive(matcher):
    result = matcher.match("I WANT TO BOOK AN APPOINTMENT")
    assert result.matched is True
    assert result.sop_name == "booking_enquiry"
