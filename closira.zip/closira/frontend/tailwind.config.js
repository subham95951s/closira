/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./App.{js,ts,tsx}", "./src/**/*.{js,ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        primary:   "#1E3A5F",
        secondary: "#2E75B6",
        accent:    "#3498DB",
        whatsapp:  "#22C55E",
        email:     "#3B82F6",
        call:      "#F59E0B",
        danger:    "#EF4444",
        warning:   "#F59E0B",
        success:   "#22C55E",
      },
    },
  },
  plugins: [],
};
