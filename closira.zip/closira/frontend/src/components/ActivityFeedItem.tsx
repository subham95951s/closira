import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Enquiry } from '../types';
import { ChannelBadge } from './ChannelBadge';
import { StatusBadge } from './StatusBadge';

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

interface Props { item: Enquiry; onPress: () => void; }

export function ActivityFeedItem({ item, onPress }: Props) {
  return (
    <TouchableOpacity style={styles.row} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.left}>
        <Text style={styles.name}>{item.customer}</Text>
        <Text style={styles.msg} numberOfLines={1}>{item.message}</Text>
        <View style={styles.badges}>
          <ChannelBadge channel={item.channel} />
          <StatusBadge status={item.status} />
        </View>
      </View>
      <View style={styles.right}>
        <Text style={styles.time}>{timeAgo(item.receivedAt)}</Text>
        <Ionicons name="chevron-forward" size={16} color="#9CA3AF" />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row:    { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 8, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 1 },
  left:   { flex: 1, gap: 4 },
  name:   { fontSize: 14, fontWeight: '700', color: '#1E3A5F' },
  msg:    { fontSize: 13, color: '#6B7280' },
  badges: { flexDirection: 'row', gap: 6, marginTop: 2 },
  right:  { alignItems: 'flex-end', gap: 4 },
  time:   { fontSize: 11, color: '#9CA3AF' },
});
