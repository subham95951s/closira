import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// ── MessageBubble ─────────────────────────────────────────────────────────────
interface BubbleProps { text: string; from: 'customer' | 'system'; time?: string; }

export function MessageBubble({ text, from, time }: BubbleProps) {
  const isCustomer = from === 'customer';
  return (
    <View style={[styles.bubbleWrap, isCustomer ? styles.leftWrap : styles.rightWrap]}>
      <View style={[styles.bubble, isCustomer ? styles.customerBubble : styles.systemBubble]}>
        <Text style={[styles.bubbleText, isCustomer ? styles.customerText : styles.systemText]}>
          {text}
        </Text>
      </View>
      {time && <Text style={styles.bubbleTime}>{time}</Text>}
    </View>
  );
}

// ── SopLabel ──────────────────────────────────────────────────────────────────
interface SopProps { sop?: string | null; }

export function SopLabel({ sop }: SopProps) {
  if (!sop) {
    return (
      <View style={styles.sopUnmatched}>
        <Ionicons name="alert-circle-outline" size={14} color="#DC2626" />
        <Text style={styles.sopUnmatchedText}>Unmatched — Auto Escalated</Text>
      </View>
    );
  }
  return (
    <View style={styles.sopMatched}>
      <Ionicons name="checkmark-circle" size={14} color="#16A34A" />
      <Text style={styles.sopMatchedText}>SOP: {sop.replace(/_/g, ' ')}</Text>
    </View>
  );
}

// ── EmptyState ────────────────────────────────────────────────────────────────
interface EmptyProps { icon: keyof typeof Ionicons.glyphMap; title: string; subtitle?: string; }

export function EmptyState({ icon, title, subtitle }: EmptyProps) {
  return (
    <View style={styles.empty}>
      <Ionicons name={icon} size={52} color="#D1D5DB" />
      <Text style={styles.emptyTitle}>{title}</Text>
      {subtitle && <Text style={styles.emptySub}>{subtitle}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  bubbleWrap:       { marginBottom: 10, maxWidth: '80%' },
  leftWrap:         { alignSelf: 'flex-start' },
  rightWrap:        { alignSelf: 'flex-end' },
  bubble:           { borderRadius: 14, padding: 12 },
  customerBubble:   { backgroundColor: '#F3F4F6', borderBottomLeftRadius: 4 },
  systemBubble:     { backgroundColor: '#1E3A5F', borderBottomRightRadius: 4 },
  bubbleText:       { fontSize: 14, lineHeight: 20 },
  customerText:     { color: '#1F2937' },
  systemText:       { color: '#fff' },
  bubbleTime:       { fontSize: 10, color: '#9CA3AF', marginTop: 3 },

  sopMatched:       { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#DCFCE7', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 },
  sopMatchedText:   { fontSize: 13, color: '#15803D', fontWeight: '600', textTransform: 'capitalize' },
  sopUnmatched:     { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#FEE2E2', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 },
  sopUnmatchedText: { fontSize: 13, color: '#DC2626', fontWeight: '600' },

  empty:      { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40, gap: 12 },
  emptyTitle: { fontSize: 16, fontWeight: '700', color: '#6B7280', textAlign: 'center' },
  emptySub:   { fontSize: 13, color: '#9CA3AF', textAlign: 'center' },
});
