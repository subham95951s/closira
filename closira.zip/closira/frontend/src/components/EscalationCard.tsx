import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Escalation } from '../types';
import { ChannelBadge } from './ChannelBadge';

interface Props { item: Escalation; onResolve: () => void; }

export function EscalationCard({ item, onResolve }: Props) {
  const isHigh = item.urgency === 'high';
  return (
    <View style={[styles.card, isHigh && styles.highBorder]}>
      <View style={styles.header}>
        <View style={styles.left}>
          <Text style={styles.name}>{item.customer}</Text>
          <ChannelBadge channel={item.channel} />
        </View>
        <View style={[styles.urgencyBadge, { backgroundColor: isHigh ? '#FEE2E2' : '#FEF3C7' }]}>
          <Ionicons name={isHigh ? 'alert-circle' : 'warning-outline'} size={12} color={isHigh ? '#DC2626' : '#D97706'} />
          <Text style={[styles.urgencyText, { color: isHigh ? '#DC2626' : '#D97706' }]}>
            {item.urgency.toUpperCase()}
          </Text>
        </View>
      </View>
      <Text style={styles.reason}>{item.reason}</Text>
      <TouchableOpacity style={styles.resolveBtn} onPress={onResolve} activeOpacity={0.8}>
        <Ionicons name="checkmark-done-outline" size={15} color="#fff" />
        <Text style={styles.resolveText}>Mark Resolved</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card:         { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  highBorder:   { borderLeftWidth: 4, borderLeftColor: '#DC2626' },
  header:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 },
  left:         { gap: 6 },
  name:         { fontSize: 15, fontWeight: '700', color: '#1E3A5F' },
  urgencyBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 99 },
  urgencyText:  { fontSize: 10, fontWeight: '800' },
  reason:       { fontSize: 13, color: '#374151', lineHeight: 19, marginBottom: 14 },
  resolveBtn:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: '#1E3A5F', borderRadius: 10, paddingVertical: 10 },
  resolveText:  { color: '#fff', fontSize: 13, fontWeight: '700' },
});
