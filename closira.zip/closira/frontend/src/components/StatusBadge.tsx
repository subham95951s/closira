import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Status } from '../types';

const CONFIG: Record<Status, { label: string; bg: string; color: string }> = {
  new:        { label: 'New',        bg: '#DBEAFE', color: '#1D4ED8' },
  processing: { label: 'Processing', bg: '#EDE9FE', color: '#7C3AED' },
  open:       { label: 'Open',       bg: '#DCFCE7', color: '#15803D' },
  escalated:  { label: 'Escalated',  bg: '#FEE2E2', color: '#DC2626' },
  closed:     { label: 'Closed',     bg: '#F3F4F6', color: '#6B7280' },
};

export function StatusBadge({ status }: { status: Status }) {
  const c = CONFIG[status];
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]}>
      <Text style={[styles.label, { color: c.color }]}>{c.label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99 },
  label: { fontSize: 11, fontWeight: '700' },
});
