import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface Props {
  label: string;
  value: number;
  icon: keyof typeof Ionicons.glyphMap;
  accent: string;
}

export function StatsCard({ label, value, icon, accent }: Props) {
  return (
    <View style={styles.card}>
      <View style={[styles.iconBox, { backgroundColor: accent + '20' }]}>
        <Ionicons name={icon} size={20} color={accent} />
      </View>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card:    { flex: 1, backgroundColor: '#fff', borderRadius: 12, padding: 14, alignItems: 'center', gap: 6, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  iconBox: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  value:   { fontSize: 26, fontWeight: '800', color: '#1E3A5F' },
  label:   { fontSize: 11, color: '#6B7280', textAlign: 'center', fontWeight: '500' },
});
