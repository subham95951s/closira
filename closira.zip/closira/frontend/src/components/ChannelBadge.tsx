import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Channel } from '../types';

const CONFIG: Record<Channel, { label: string; icon: keyof typeof Ionicons.glyphMap; bg: string; color: string }> = {
  whatsapp: { label: 'WhatsApp', icon: 'logo-whatsapp',  bg: '#DCFCE7', color: '#16A34A' },
  email:    { label: 'Email',    icon: 'mail-outline',   bg: '#DBEAFE', color: '#2563EB' },
  call:     { label: 'Call',     icon: 'call-outline',   bg: '#FEF3C7', color: '#D97706' },
};

export function ChannelBadge({ channel }: { channel: Channel }) {
  const c = CONFIG[channel];
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]}>
      <Ionicons name={c.icon} size={11} color={c.color} />
      <Text style={[styles.label, { color: c.color }]}>{c.label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99 },
  label: { fontSize: 11, fontWeight: '600' },
});
