import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Enquiry } from '../types';
import { ChannelBadge } from './ChannelBadge';
import { StatusBadge } from './StatusBadge';

function fmtTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

interface Props { item: Enquiry; onPress: () => void; }

export function LeadCard({ item, onPress }: Props) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.75}>
      <View style={styles.header}>
        <Text style={styles.name}>{item.customer}</Text>
        <Text style={styles.time}>{fmtTime(item.receivedAt)}</Text>
      </View>
      <Text style={styles.msg} numberOfLines={2}>{item.message}</Text>
      {item.matched_sop && (
        <View style={styles.sopRow}>
          <Ionicons name="checkmark-circle" size={13} color="#16A34A" />
          <Text style={styles.sop}>{item.matched_sop.replace(/_/g, ' ')}</Text>
        </View>
      )}
      <View style={styles.footer}>
        <ChannelBadge channel={item.channel} />
        <StatusBadge status={item.status} />
        <Ionicons name="chevron-forward" size={15} color="#9CA3AF" style={{ marginLeft: 'auto' }} />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card:   { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  name:   { fontSize: 15, fontWeight: '700', color: '#1E3A5F' },
  time:   { fontSize: 12, color: '#9CA3AF' },
  msg:    { fontSize: 13, color: '#374151', lineHeight: 19, marginBottom: 8 },
  sopRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 10 },
  sop:    { fontSize: 12, color: '#16A34A', fontWeight: '600', textTransform: 'capitalize' },
  footer: { flexDirection: 'row', alignItems: 'center', gap: 8 },
});
