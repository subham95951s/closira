import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { FollowUp } from '../types';
import { ChannelBadge } from './ChannelBadge';

function fmtDue(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function isOverdue(iso: string) {
  return new Date(iso).getTime() < Date.now();
}

interface Props { item: FollowUp; onDone: () => void; }

export function FollowUpCard({ item, onDone }: Props) {
  const overdue = !item.done && isOverdue(item.dueAt);
  return (
    <View style={[styles.card, item.done && styles.doneCard]}>
      <View style={styles.row}>
        <TouchableOpacity onPress={onDone} disabled={item.done} style={styles.checkbox}>
          <Ionicons
            name={item.done ? 'checkbox' : 'square-outline'}
            size={22}
            color={item.done ? '#22C55E' : '#9CA3AF'}
          />
        </TouchableOpacity>
        <View style={styles.content}>
          <Text style={[styles.name, item.done && styles.strikethrough]}>{item.customer}</Text>
          <Text style={[styles.preview, item.done && styles.strikethrough]} numberOfLines={1}>
            {item.messagePreview}
          </Text>
          <View style={styles.meta}>
            <ChannelBadge channel={item.channel} />
            <View style={[styles.dueBadge, { backgroundColor: overdue ? '#FEE2E2' : '#F3F4F6' }]}>
              <Ionicons name="time-outline" size={11} color={overdue ? '#DC2626' : '#6B7280'} />
              <Text style={[styles.dueText, { color: overdue ? '#DC2626' : '#6B7280' }]}>
                {item.done ? 'Done' : fmtDue(item.dueAt)}
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card:        { backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 8, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 1 },
  doneCard:    { opacity: 0.6 },
  row:         { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  checkbox:    { marginTop: 2 },
  content:     { flex: 1, gap: 4 },
  name:        { fontSize: 14, fontWeight: '700', color: '#1E3A5F' },
  preview:     { fontSize: 13, color: '#6B7280' },
  strikethrough: { textDecorationLine: 'line-through', color: '#9CA3AF' },
  meta:        { flexDirection: 'row', gap: 6, alignItems: 'center', marginTop: 2 },
  dueBadge:    { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 99 },
  dueText:     { fontSize: 11, fontWeight: '600' },
});
