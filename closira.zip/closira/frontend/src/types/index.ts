export type Channel = 'whatsapp' | 'email' | 'call';
export type Status  = 'new' | 'processing' | 'open' | 'escalated' | 'closed';
export type Urgency = 'high' | 'medium' | 'low';

export interface StatusEvent {
  type: string;
  actor: 'system' | 'agent';
  timestamp: string;
  description?: string;
}

export interface Enquiry {
  id: string;
  customer: string;
  channel: Channel;
  message: string;
  status: Status;
  matched_sop?: string | null;
  suggested_response?: string | null;
  escalation_reason?: string | null;
  followup_due_at?: string | null;
  summary?: string;
  receivedAt: string;
  events: StatusEvent[];
}

export interface Escalation {
  id: string;
  enquiry_id: string;
  customer: string;
  channel: Channel;
  reason: string;
  urgency: Urgency;
  receivedAt: string;
}

export interface FollowUp {
  id: string;
  enquiry_id: string;
  customer: string;
  channel: Channel;
  dueAt: string;
  messagePreview: string;
  done: boolean;
}

export interface DashboardStats {
  total_leads_today: number;
  missed_enquiries: number;
  open_escalations: number;
  followups_due: number;
}
