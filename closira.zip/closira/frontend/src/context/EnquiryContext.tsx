import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { Enquiry, Escalation, FollowUp, DashboardStats } from '../types';

import enquiriesData  from '../../mock/enquiries.json';
import escalationsData from '../../mock/escalations.json';
import followupsData  from '../../mock/followups.json';
import statsData      from '../../mock/stats.json';

// ── State ─────────────────────────────────────────────────────────────────────
interface AppState {
  enquiries:   Enquiry[];
  escalations: Escalation[];
  followups:   FollowUp[];
  stats:       DashboardStats;
}

const initialState: AppState = {
  enquiries:   enquiriesData  as Enquiry[],
  escalations: escalationsData as Escalation[],
  followups:   followupsData  as FollowUp[],
  stats:       statsData       as DashboardStats,
};

// ── Actions ───────────────────────────────────────────────────────────────────
type Action =
  | { type: 'RESOLVE_ESCALATION'; id: string }
  | { type: 'MARK_FOLLOWUP_DONE'; id: string };

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'RESOLVE_ESCALATION': {
      const escalations = state.escalations.filter(e => e.id !== action.id);
      return {
        ...state,
        escalations,
        stats: { ...state.stats, open_escalations: escalations.length },
      };
    }
    case 'MARK_FOLLOWUP_DONE': {
      const followups = state.followups.map(f =>
        f.id === action.id ? { ...f, done: true } : f
      );
      const dueCount = followups.filter(f => !f.done).length;
      return {
        ...state,
        followups,
        stats: { ...state.stats, followups_due: dueCount },
      };
    }
    default:
      return state;
  }
}

// ── Context ───────────────────────────────────────────────────────────────────
interface AppContextValue extends AppState {
  resolveEscalation: (id: string) => void;
  markFollowUpDone:  (id: string) => void;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <AppContext.Provider value={{
      ...state,
      resolveEscalation: (id) => dispatch({ type: 'RESOLVE_ESCALATION', id }),
      markFollowUpDone:  (id) => dispatch({ type: 'MARK_FOLLOWUP_DONE', id }),
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
}
