import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { DashboardScreen }  from '../screens/DashboardScreen';
import { LeadsScreen }      from '../screens/LeadsScreen';
import { EscalationsScreen }from '../screens/EscalationsScreen';
import { FollowUpsScreen }  from '../screens/FollowUpsScreen';
import { useAppContext }     from '../context/EnquiryContext';

const Tab = createBottomTabNavigator();

export function BottomTabNavigator() {
  const { escalations, followups } = useAppContext();
  const pendingFollowups = followups.filter(f => !f.done).length;

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerStyle:       { backgroundColor: '#1E3A5F' },
        headerTintColor:   '#fff',
        headerTitleStyle:  { fontWeight: '700', fontSize: 17 },
        tabBarStyle:       { backgroundColor: '#fff', borderTopColor: '#F3F4F6', height: 60, paddingBottom: 8 },
        tabBarActiveTintColor:   '#1E3A5F',
        tabBarInactiveTintColor: '#9CA3AF',
        tabBarLabelStyle:  { fontSize: 11, fontWeight: '600' },
        tabBarIcon: ({ focused, color, size }) => {
          const icons: Record<string, [string, string]> = {
            Dashboard:   ['home',                'home-outline'],
            Leads:       ['people',              'people-outline'],
            Escalations: ['alert-circle',        'alert-circle-outline'],
            FollowUps:   ['time',                'time-outline'],
          };
          const [active, inactive] = icons[route.name] || ['ellipse', 'ellipse-outline'];
          return <Ionicons name={(focused ? active : inactive) as any} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard"   component={DashboardScreen}   options={{ title: 'Dashboard' }} />
      <Tab.Screen name="Leads"       component={LeadsScreen}       options={{ title: 'Leads' }} />
      <Tab.Screen
        name="Escalations"
        component={EscalationsScreen}
        options={{
          title: 'Escalations',
          tabBarBadge: escalations.length > 0 ? escalations.length : undefined,
          tabBarBadgeStyle: { backgroundColor: '#EF4444' },
        }}
      />
      <Tab.Screen
        name="FollowUps"
        component={FollowUpsScreen}
        options={{
          title: 'Follow-Ups',
          tabBarBadge: pendingFollowups > 0 ? pendingFollowups : undefined,
          tabBarBadgeStyle: { backgroundColor: '#8B5CF6' },
        }}
      />
    </Tab.Navigator>
  );
}
