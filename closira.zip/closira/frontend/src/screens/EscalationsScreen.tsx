import React from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { useAppContext } from '../context/EnquiryContext';
import { EscalationCard } from '../components/EscalationCard';
import { EmptyState } from '../components/SharedComponents';

export function EscalationsScreen() {
  const { escalations, resolveEscalation } = useAppContext();

  return (
    <View style={styles.screen}>
      {escalations.length === 0 ? (
        <EmptyState
          icon="checkmark-circle-outline"
          title="All clear!"
          subtitle="No active escalations right now."
        />
      ) : (
        <FlatList
          data={escalations}
          keyExtractor={i => i.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <EscalationCard item={item} onResolve={() => resolveEscalation(item.id)} />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#F8FAFC' },
  list:   { padding: 16, paddingBottom: 40 },
});
