import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAppContext } from '../context/EnquiryContext';
import { LeadCard } from '../components/LeadCard';
import { EmptyState } from '../components/SharedComponents';
import { Status } from '../types';

const FILTERS: { label: string; value: Status | 'all' }[] = [
  { label: 'All',       value: 'all' },
  { label: 'New',       value: 'new' },
  { label: 'Open',      value: 'open' },
  { label: 'Escalated', value: 'escalated' },
  { label: 'Closed',    value: 'closed' },
];

export function LeadsScreen() {
  const { enquiries } = useAppContext();
  const navigation = useNavigation<any>();
  const [filter, setFilter] = useState<Status | 'all'>('all');

  const filtered = filter === 'all'
    ? enquiries
    : enquiries.filter(e => e.status === filter);

  return (
    <View style={styles.screen}>
      {/* Filter chips */}
      <View style={styles.filterBar}>
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f.value}
            style={[styles.chip, filter === f.value && styles.chipActive]}
            onPress={() => setFilter(f.value)}
          >
            <Text style={[styles.chipText, filter === f.value && styles.chipTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {filtered.length === 0 ? (
        <EmptyState icon="people-outline" title="No leads found" subtitle="Try a different filter." />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={i => i.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <LeadCard
              item={item}
              onPress={() => navigation.navigate('ConversationDetail', { enquiryId: item.id })}
            />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen:        { flex: 1, backgroundColor: '#F8FAFC' },
  filterBar:     { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  chip:          { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 99, backgroundColor: '#F3F4F6' },
  chipActive:    { backgroundColor: '#1E3A5F' },
  chipText:      { fontSize: 13, fontWeight: '600', color: '#6B7280' },
  chipTextActive:{ color: '#fff' },
  list:          { padding: 16, paddingBottom: 40 },
});
