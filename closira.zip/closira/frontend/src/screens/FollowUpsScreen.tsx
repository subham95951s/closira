import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { useAppContext } from '../context/EnquiryContext';
import { FollowUpCard } from '../components/FollowUpCard';
import { EmptyState } from '../components/SharedComponents';

export function FollowUpsScreen() {
  const { followups, markFollowUpDone } = useAppContext();
  const pending   = followups.filter(f => !f.done);
  const completed = followups.filter(f => f.done);

  return (
    <View style={styles.screen}>
      {followups.length === 0 ? (
        <EmptyState icon="time-outline" title="No follow-ups scheduled" />
      ) : (
        <FlatList
          data={[...pending, ...completed]}
          keyExtractor={i => i.id}
          contentContainerStyle={styles.list}
          ListHeaderComponent={
            pending.length > 0 ? <Text style={styles.sectionLabel}>Pending ({pending.length})</Text> : null
          }
          renderItem={({ item, index }) => (
            <>
              {item.done && index === pending.length && (
                <Text style={[styles.sectionLabel, styles.doneLabel]}>Completed ({completed.length})</Text>
              )}
              <FollowUpCard item={item} onDone={() => markFollowUpDone(item.id)} />
            </>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen:       { flex: 1, backgroundColor: '#F8FAFC' },
  list:         { padding: 16, paddingBottom: 40 },
  sectionLabel: { fontSize: 13, fontWeight: '700', color: '#6B7280', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.5 },
  doneLabel:    { marginTop: 16 },
});
