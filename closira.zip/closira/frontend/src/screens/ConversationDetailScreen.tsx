import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useRoute, RouteProp } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAppContext } from '../context/EnquiryContext';
import { ChannelBadge } from '../components/ChannelBadge';
import { StatusBadge } from '../components/StatusBadge';
import { MessageBubble, SopLabel, EmptyState } from '../components/SharedComponents';

type RouteParams = { ConversationDetail: { enquiryId: string } };

function fmtTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

const EVENT_ICON: Record<string, keyof typeof Ionicons.glyphMap> = {
  created:              'add-circle-outline',
  processing_started:   'sync-outline',
  sop_matched:          'checkmark-circle-outline',
  escalated:            'alert-circle-outline',
  escalation_triggered: 'alert-circle-outline',
  followup_scheduled:   'time-outline',
  closed:               'lock-closed-outline',
};

export function ConversationDetailScreen() {
  const route = useRoute<RouteProp<RouteParams, 'ConversationDetail'>>();
  const { enquiries } = useAppContext();
  const enquiry = enquiries.find(e => e.id === route.params.enquiryId);

  if (!enquiry) {
    return <EmptyState icon="alert-circle-outline" title="Enquiry not found" />;
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      {/* Customer header */}
      <View style={styles.headerCard}>
        <Text style={styles.customerName}>{enquiry.customer}</Text>
        <View style={styles.badges}>
          <ChannelBadge channel={enquiry.channel} />
          <StatusBadge status={enquiry.status} />
        </View>
        {enquiry.summary && (
          <View style={styles.summaryBox}>
            <Ionicons name="information-circle-outline" size={14} color="#2E75B6" />
            <Text style={styles.summaryText}>{enquiry.summary}</Text>
          </View>
        )}
      </View>

      {/* SOP match */}
      <Text style={styles.sectionLabel}>SOP Match</Text>
      <SopLabel sop={enquiry.matched_sop} />

      {/* Conversation thread */}
      <Text style={styles.sectionLabel}>Conversation</Text>
      <View style={styles.thread}>
        <MessageBubble
          from="customer"
          text={enquiry.message}
          time={fmtTime(enquiry.receivedAt)}
        />
        {enquiry.suggested_response && (
          <MessageBubble
            from="system"
            text={enquiry.suggested_response}
            time="Auto-reply"
          />
        )}
        {enquiry.escalation_reason && !enquiry.suggested_response && (
          <View style={styles.escalationNote}>
            <Ionicons name="alert-circle" size={14} color="#DC2626" />
            <Text style={styles.escalationText}>
              Escalated: {enquiry.escalation_reason}
            </Text>
          </View>
        )}
      </View>

      {/* Status timeline */}
      <Text style={styles.sectionLabel}>Status Timeline</Text>
      <View style={styles.timeline}>
        {enquiry.events.map((ev, i) => (
          <View key={i} style={styles.timelineRow}>
            <View style={styles.timelineLeft}>
              <View style={styles.dot}>
                <Ionicons name={EVENT_ICON[ev.type] || 'ellipse-outline'} size={14} color="#2E75B6" />
              </View>
              {i < enquiry.events.length - 1 && <View style={styles.line} />}
            </View>
            <View style={styles.timelineContent}>
              <Text style={styles.eventType}>{ev.type.replace(/_/g, ' ')}</Text>
              {ev.description && <Text style={styles.eventDesc}>{ev.description}</Text>}
              <Text style={styles.eventTime}>{new Date(ev.timestamp).toLocaleString()}</Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen:          { flex: 1, backgroundColor: '#F8FAFC' },
  content:         { padding: 16, paddingBottom: 40, gap: 16 },
  headerCard:      { backgroundColor: '#fff', borderRadius: 16, padding: 16, gap: 10, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  customerName:    { fontSize: 20, fontWeight: '800', color: '#1E3A5F' },
  badges:          { flexDirection: 'row', gap: 8 },
  summaryBox:      { flexDirection: 'row', alignItems: 'flex-start', gap: 6, backgroundColor: '#EFF6FF', borderRadius: 10, padding: 10, marginTop: 4 },
  summaryText:     { flex: 1, fontSize: 13, color: '#1D4ED8', lineHeight: 18 },
  sectionLabel:    { fontSize: 13, fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.5 },
  thread:          { backgroundColor: '#fff', borderRadius: 16, padding: 16, gap: 4, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 1 },
  escalationNote:  { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#FEE2E2', borderRadius: 10, padding: 10 },
  escalationText:  { flex: 1, fontSize: 13, color: '#DC2626' },
  timeline:        { backgroundColor: '#fff', borderRadius: 16, padding: 16, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 1 },
  timelineRow:     { flexDirection: 'row', gap: 12 },
  timelineLeft:    { alignItems: 'center', width: 24 },
  dot:             { width: 24, height: 24, borderRadius: 12, backgroundColor: '#EFF6FF', alignItems: 'center', justifyContent: 'center' },
  line:            { width: 2, flex: 1, backgroundColor: '#E5E7EB', marginVertical: 4 },
  timelineContent: { flex: 1, paddingBottom: 16, gap: 2 },
  eventType:       { fontSize: 13, fontWeight: '700', color: '#1E3A5F', textTransform: 'capitalize' },
  eventDesc:       { fontSize: 12, color: '#6B7280' },
  eventTime:       { fontSize: 11, color: '#9CA3AF' },
});
