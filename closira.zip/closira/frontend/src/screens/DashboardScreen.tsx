import React from 'react';
import { View, Text, FlatList, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAppContext } from '../context/EnquiryContext';
import { StatsCard } from '../components/StatsCard';
import { ActivityFeedItem } from '../components/ActivityFeedItem';
import { EmptyState } from '../components/SharedComponents';

export function DashboardScreen() {
  const { stats, enquiries } = useAppContext();
  const navigation = useNavigation<any>();
  const sorted = [...enquiries].sort(
    (a, b) => new Date(b.receivedAt).getTime() - new Date(a.receivedAt).getTime()
  ).slice(0, 10);

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good morning 👋</Text>
          <Text style={styles.title}>Closira Dashboard</Text>
        </View>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>CL</Text>
        </View>
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        <StatsCard label="Leads Today"    value={stats.total_leads_today}  icon="people-outline"        accent="#2E75B6" />
        <StatsCard label="Missed"         value={stats.missed_enquiries}   icon="call-outline"          accent="#EF4444" />
        <StatsCard label="Escalations"    value={stats.open_escalations}   icon="alert-circle-outline"  accent="#F59E0B" />
        <StatsCard label="Follow-Ups Due" value={stats.followups_due}      icon="time-outline"          accent="#8B5CF6" />
      </View>

      {/* Quick Actions */}
      <Text style={styles.sectionTitle}>Quick Actions</Text>
      <View style={styles.actionsRow}>
        {[
          { label: 'Leads',        icon: 'list-outline',         tab: 'Leads',       color: '#2E75B6' },
          { label: 'Escalations',  icon: 'alert-circle-outline', tab: 'Escalations', color: '#EF4444' },
          { label: 'Follow-Ups',   icon: 'time-outline',         tab: 'FollowUps',   color: '#8B5CF6' },
        ].map(a => (
          <TouchableOpacity
            key={a.tab}
            style={styles.actionBtn}
            onPress={() => navigation.navigate(a.tab)}
            activeOpacity={0.75}
          >
            <View style={[styles.actionIcon, { backgroundColor: a.color + '15' }]}>
              <Ionicons name={a.icon as any} size={20} color={a.color} />
            </View>
            <Text style={styles.actionLabel}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Activity Feed */}
      <Text style={styles.sectionTitle}>Recent Activity</Text>
      {sorted.length === 0 ? (
        <EmptyState icon="chatbubbles-outline" title="No activity today" subtitle="Enquiries will appear here as they come in." />
      ) : (
        sorted.map(item => (
          <ActivityFeedItem
            key={item.id}
            item={item}
            onPress={() => navigation.navigate('ConversationDetail', { enquiryId: item.id })}
          />
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen:       { flex: 1, backgroundColor: '#F8FAFC' },
  content:      { padding: 16, paddingBottom: 40 },
  header:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  greeting:     { fontSize: 13, color: '#6B7280' },
  title:        { fontSize: 22, fontWeight: '800', color: '#1E3A5F' },
  avatar:       { width: 40, height: 40, borderRadius: 20, backgroundColor: '#1E3A5F', alignItems: 'center', justifyContent: 'center' },
  avatarText:   { color: '#fff', fontWeight: '700', fontSize: 14 },
  statsRow:     { flexDirection: 'row', gap: 8, marginBottom: 24 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#1E3A5F', marginBottom: 12 },
  actionsRow:   { flexDirection: 'row', gap: 10, marginBottom: 24 },
  actionBtn:    { flex: 1, backgroundColor: '#fff', borderRadius: 14, padding: 14, alignItems: 'center', gap: 8, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  actionIcon:   { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  actionLabel:  { fontSize: 12, fontWeight: '600', color: '#374151' },
});
